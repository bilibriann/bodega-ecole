import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Producto } from '../entities/producto.entity';
import { CreateProductoDto } from '../dto/create-producto.dto';
import { Movimiento } from '../../movimientos/entities/movimiento.entity';

type FindAllParams = { nombre?: string };

export type ProductoResumen = {
  id: string;
  nombre: string;
  descripcion: string | null;
  cantidad: number;
  unidad: string;
  ultimaActualizacion: Date;
};

@Injectable()
export class ProductosService {
  constructor(@InjectRepository(Producto) private repo: Repository<Producto>) {}

  async findAll(params: FindAllParams = {}): Promise<ProductoResumen[]> {
    const qb = this.repo
      .createQueryBuilder('p')
      .leftJoin('p.lotes', 'l')
      .leftJoin(Movimiento, 'm', 'm.productoId = p.id')
      .select('p.id', 'id')
      .addSelect('p.nombre', 'nombre')
      .addSelect('p.descripcion', 'descripcion')
      .addSelect('p.unidad', 'unidad')
      .addSelect('COALESCE(SUM(l.cantidadActual), 0)', 'cantidad')
      .addSelect('COALESCE(MAX(m.fecha), p.updatedAt)', 'ultimaActualizacion')
      .groupBy('p.id')
      .addGroupBy('p.nombre')
      .addGroupBy('p.descripcion')
      .addGroupBy('p.unidad')
      .addGroupBy('p.updatedAt')
      .orderBy('p.nombre', 'ASC');

    if (params.nombre?.trim()) {
      qb.andWhere('LOWER(p.nombre) LIKE :nombre', {
        nombre: `%${params.nombre.trim().toLowerCase()}%`,
      });
    }

    const rows: Array<{
      id: string;
      nombre: string;
      descripcion: string | null;
      cantidad: number;
      unidad: string;
      ultimaActualizacion: Date;
    }> = await qb.getRawMany();

    return rows.map((r) => ({
      id: r.id,
      nombre: r.nombre,
      descripcion: r.descripcion ?? null,
      cantidad: Number(r.cantidad ?? 0),
      unidad: r.unidad,
      ultimaActualizacion: new Date(r.ultimaActualizacion),
    }));
  }

  create(dto: CreateProductoDto) {
    return this.repo.save(this.repo.create(dto));
  }
}
