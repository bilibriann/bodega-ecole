import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsEnum,
  IsOptional,
  IsString,
  MaxLength,
  MinLength,
} from 'class-validator';
import { Unidad } from '../entities/producto.entity';

export class CreateProductoDto {
  @ApiProperty({ example: 'Harina' })
  @IsString()
  @MinLength(2)
  @MaxLength(150)
  nombre: string;

  @ApiPropertyOptional({ example: 'Harina sin polvos, ideal para repostería.' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  descripcion?: string;

  @ApiProperty({ enum: Unidad, example: Unidad.KG })
  @IsEnum(Unidad)
  unidad: Unidad;
}
