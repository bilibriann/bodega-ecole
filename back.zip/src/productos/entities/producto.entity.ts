import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';
import { Lote } from '../../lotes/entities/lote.entity';

export enum Unidad {
  UN = 'UN',
  KG = 'KG',
  LT = 'LT',
  GR = 'GR',
  ML = 'ML',
}

@Entity('productos')
export class Producto {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 150 })
  nombre: string;

  @Column({ length: 255, nullable: true })
  descripcion?: string | null;

  @Column({ type: 'enum', enum: Unidad })
  unidad: Unidad;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @OneToMany(() => Lote, (lote) => lote.producto)
  lotes: Lote[];
}
